<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss" scoped>
* {
  margin: 0;
  min-height: 100vh;
  background-color: #efece6;
}

</style>
