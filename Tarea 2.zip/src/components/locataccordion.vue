<template>
  <div class="accordion" role="tablist">
    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-1 variant="green">AJ Katzenmaier Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>24 W. Walton St., Chicago, IL 60610</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.654246110986!2d-87.63123908531662!3d41.900292379220424!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd34e07f6bac3%3A0x68a82e5d59952c86!2s24%20W%20Walton%20St%2C%20Chicago%2C%20IL%2060610%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594820189684!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-2 variant="green">Greenbay Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-2" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>1734 N. Orleans St., Chicago, IL 60614</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.025884368855!2d-87.64002798531602!3d41.913802279219425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd34073f306a3%3A0x9e1726bbf8f23f0e!2s1734%20N%20Orleans%20St%2C%20Chicago%2C%20IL%2060614%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594828517620!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-3 variant="green">Howard A Yeager Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-3" accordion="my-accordion" role="tabpanel">
        <b-card-body class="left-border">
          <b-card-text>2245 N. Southport Ave., Chicago, IL 60614</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2968.585683085616!2d-87.66511458531562!3d41.92326457921871!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd2e37f9b8d2d%3A0x62ad8b907dd755d6!2s2245%20N%20Southport%20Ave%2C%20Chicago%2C%20IL%2060614%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594829099405!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-4 variant="green">Marjorie P Hart Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-4" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>2625 N. Orchard St., Chicago, IL 60614</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2968.291914658433!2d-87.64808628556621!3d41.929578279218106!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd30f2630e551%3A0x3e719e44a5cef714!2s2625%20N%20Orchard%20St%2C%20Chicago%2C%20IL%2060614%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594829239198!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-5 variant="green">North Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-5" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>1409 N. Ogden Ave., Chicago, IL 60610</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.3564693923263!2d-87.64765898556725!3d41.906695079219915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd33a674ca85d%3A0x9940c7163c4950c5!2s1409%20N%20Ogden%20Ave%2C%20Chicago%2C%20IL%2060610%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594829310601!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-6 variant="green">South Elementary</b-button>
      </b-card-header>
      <b-collapse id="accordion-6" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>2101 N. Fremont St., Chicago, IL 60614</b-card-text>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2968.7479505250662!2d-87.65355538556668!3d41.91977677921893!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd3196fb41dc7%3A0x970be7f7d6336df5!2s2101%20N%20Fremont%20St%2C%20Chicago%2C%20IL%2060614%2C%20EE.%20UU.!5e0!3m2!1ses-419!2sar!4v1594829363211!5m2!1ses-419!2sar" width="300" height="320" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </b-card-body>
      </b-collapse>
    </b-card>
  </div>
</template>

<script>
  export default {
    name: "Accordion",
  }
</script>

<style lang="scss" scoped>
  .accordion{
    width: 95vw;
  }

  .btn-green {
    color: #fff;
    background-color: #50c35d;
    border-color:#50c35d;
  }

  #accordion-1, #accordion-2, #accordion-3, #accordion-4, #accordion-5, #accordion-6{
    box-shadow: 0px 0px 10px grey;
    background-image: linear-gradient(to bottom, #bdbdbd, #efece6);    border-left-color: #DDA448;
    border-left: 7px #dda448 solid;
    border-radius: 0px 0px 25px 25px; 
    width: 95vw;
    align-self: center;
  }

  .p-1, .mb-1{
    padding: 0 !important;
    background-color: #efece6;
    font-weight: 700;
  }

  .mb-1{
    margin-bottom: 15px !important;
  }

  .btn{
    font-weight: 700;
    border-radius: 20px;
  }

  .btn:focus{
    border-radius: 20px 20px 0 0;
  }

</style>